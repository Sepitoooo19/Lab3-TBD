create function log_failed_order() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.status = 'FALLIDA' AND OLD.status IS DISTINCT FROM NEW.status THEN
        RAISE NOTICE 'Pedido % marcado como FALLIDA', NEW.id;
END IF;
RETURN NEW;
END;
$$;

alter function log_failed_order() owner to postgres;

