create function st_transformpipeline(geom geometry, pipeline text, to_srid integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT public.postgis_transform_pipeline_geometry($1, $2, TRUE, $3)$$;

alter function st_transformpipeline(geometry, text, integer) owner to postgres;

