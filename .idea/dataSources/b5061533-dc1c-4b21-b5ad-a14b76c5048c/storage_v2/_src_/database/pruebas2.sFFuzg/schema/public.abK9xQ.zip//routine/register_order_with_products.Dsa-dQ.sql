create procedure register_order_with_products(IN p_order_date timestamp without time zone, IN p_status character varying, IN p_client_id integer, IN p_product_ids integer[], IN p_dealer_id integer DEFAULT NULL::integer, IN p_estimated_route geometry DEFAULT NULL::geometry)
    language plpgsql
as
$$
DECLARE
v_order_id INT;
    v_product_id INT;
    v_total_price FLOAT := 0.0;
    v_client_location GEOMETRY;
    v_company_location GEOMETRY;
    v_estimated_route GEOMETRY;
BEGIN
    -- 1. Validar que haya productos
    IF array_length(p_product_ids, 1) IS NULL OR array_length(p_product_ids, 1) = 0 THEN
        RAISE EXCEPTION 'La orden debe contener al menos un producto';
END IF;

    -- 2. Obtener ubicación del cliente
SELECT ubication INTO v_client_location
FROM clients
WHERE id = p_client_id;

IF v_client_location IS NULL THEN
        RAISE EXCEPTION 'El cliente con ID % no tiene ubicación registrada', p_client_id;
END IF;

    -- 3. Obtener empresa del último producto
SELECT c.ubication INTO v_company_location
FROM products p
         JOIN companies c ON p.company_id = c.id
WHERE p.id = p_product_ids[array_length(p_product_ids, 1)]
    LIMIT 1;

IF v_company_location IS NULL THEN
        RAISE EXCEPTION 'No se pudo determinar la ubicación de la empresa para el producto ID %',
                        p_product_ids[array_length(p_product_ids, 1)];
END IF;

    -- 4. Calcular ruta estimada si no viene como parámetro
    IF p_estimated_route IS NULL THEN
        v_estimated_route := ST_MakeLine(v_company_location, v_client_location);
ELSE
        v_estimated_route := p_estimated_route;
END IF;

    -- 5. Calcular el precio total de los productos
SELECT COALESCE(SUM(price), 0)
INTO v_total_price
FROM products
WHERE id = ANY(p_product_ids);

-- 6. Insertar la orden con la ruta estimada
INSERT INTO orders (
    order_date,
    status,
    client_id,
    dealer_id,
    total_price,
    estimated_route
)
VALUES (
           p_order_date,
           p_status,
           p_client_id,
           p_dealer_id,
           v_total_price,
           v_estimated_route
       )
    RETURNING id INTO v_order_id;

-- 7. Procesar productos
FOREACH v_product_id IN ARRAY p_product_ids LOOP
        -- Verificar existencia
        IF NOT EXISTS (SELECT 1 FROM products WHERE id = v_product_id) THEN
            RAISE EXCEPTION 'Producto con ID % no existe', v_product_id;
END IF;

        -- Registrar producto en la orden
INSERT INTO order_products (order_id, product_id)
VALUES (v_order_id, v_product_id);

-- Reducir stock
UPDATE products
SET stock = stock - 1
WHERE id = v_product_id AND stock > 0;

IF NOT FOUND THEN
            RAISE EXCEPTION 'Sin stock para el producto ID %', v_product_id;
END IF;
END LOOP;
END;
$$;

alter procedure register_order_with_products(timestamp, varchar, integer, integer[], integer, geometry) owner to postgres;

