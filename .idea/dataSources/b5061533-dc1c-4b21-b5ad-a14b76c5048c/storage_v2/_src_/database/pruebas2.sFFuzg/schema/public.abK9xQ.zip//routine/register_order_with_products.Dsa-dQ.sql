create procedure register_order_with_products(IN p_order_date timestamp without time zone, IN p_status character varying, IN p_client_id integer, IN p_product_ids integer[], IN p_dealer_id integer DEFAULT NULL::integer, IN p_estimated_route geometry DEFAULT NULL::geometry)
    language plpgsql
as
$$
DECLARE
v_order_id INT;
    v_product_id INT;
    v_total_price FLOAT := 0.0;
    v_company_location GEOMETRY;
    v_client_location GEOMETRY;
    v_route GEOMETRY;
    v_last_product_id INT;
BEGIN
    -- Validaciones iniciales
    IF array_length(p_product_ids, 1) IS NULL OR array_length(p_product_ids, 1) = 0 THEN
        RAISE EXCEPTION 'La lista de productos no puede estar vacía';
END IF;
    
    IF NOT EXISTS (SELECT 1 FROM clients WHERE id = p_client_id) THEN
        RAISE EXCEPTION 'Cliente con ID % no existe', p_client_id;
END IF;
    
    -- Obtener último producto ID
    v_last_product_id := p_product_ids[array_length(p_product_ids, 1)];
    
    -- Calcular precio total
SELECT COALESCE(SUM(price), 0)
INTO v_total_price
FROM products
WHERE id = ANY(p_product_ids);

-- Obtener ubicaciones
BEGIN
SELECT ubication INTO v_client_location
FROM clients
WHERE id = p_client_id;

SELECT c.ubication INTO v_company_location
FROM products p
         JOIN companies c ON p.company_id = c.id
WHERE p.id = v_last_product_id;
EXCEPTION WHEN NO_DATA_FOUND THEN
        RAISE EXCEPTION 'No se pudo obtener ubicación para cliente o compañía';
END;
    
    -- Crear ruta estimada
    IF p_estimated_route IS NULL THEN
        v_route := ST_MakeLine(v_company_location, v_client_location);
ELSE
        v_route := p_estimated_route;
END IF;
    
    -- Insertar orden
INSERT INTO orders (order_date, status, client_id, dealer_id, total_price, estimated_route)
VALUES (p_order_date, p_status, p_client_id, p_dealer_id, v_total_price, v_route)
    RETURNING id INTO v_order_id;

-- Procesar productos
FOREACH v_product_id IN ARRAY p_product_ids LOOP
        -- Verificar existencia del producto
        IF NOT EXISTS (SELECT 1 FROM products WHERE id = v_product_id) THEN
            RAISE EXCEPTION 'Producto con ID % no existe', v_product_id;
END IF;

INSERT INTO order_products (order_id, product_id)
VALUES (v_order_id, v_product_id);

-- Actualizar stock con verificación
UPDATE products
SET stock = stock - 1
WHERE id = v_product_id AND stock > 0;

IF NOT FOUND THEN
            RAISE EXCEPTION 'Sin stock disponible para el producto ID %', v_product_id;
END IF;
END LOOP;
    
    -- Eliminamos el COMMIT/ROLLBACK explícito
END;
$$;

alter procedure register_order_with_products(timestamp, varchar, integer, integer[], integer, geometry) owner to postgres;

