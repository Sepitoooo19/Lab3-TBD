create function insert_auto_rating_if_late() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Verifica si el estado se cambió a ENTREGADO y la entrega fue hace más de 48 horas
    IF NEW.status = 'ENTREGADO'
       AND OLD.status IS DISTINCT FROM NEW.status
       AND NEW.delivery_date IS NOT NULL
       AND NEW.delivery_date <= NOW() - INTERVAL '48 hours' THEN

        -- Verifica si ya existe una calificación para esta orden
        IF NOT EXISTS (
            SELECT 1 FROM ratings WHERE order_id = NEW.id
        ) THEN
            INSERT INTO ratings (rating, comment, date, client_id, dealer_id, order_id)
            VALUES (
                1,
                'Calificación automática: no se recibió calificación en 48h.',
                CURRENT_DATE,
                NEW.client_id,
                NEW.dealer_id,
                NEW.id
            );
END IF;
END IF;

RETURN NEW;
END;
$$;

alter function insert_auto_rating_if_late() owner to postgres;

