create procedure change_order_status(IN p_order_id integer, IN p_new_status character varying, IN p_delivery_date timestamp without time zone DEFAULT NULL::timestamp without time zone)
    language plpgsql
as
$$
DECLARE
v_current_status VARCHAR;
BEGIN
    -- Validar que el pedido exista y obtener su estado actual
SELECT status INTO v_current_status
FROM orders
WHERE id = p_order_id;

IF NOT FOUND THEN
        RAISE EXCEPTION 'Pedido con ID % no existe', p_order_id;
END IF;

    -- Validar que aún no esté finalizado
    IF v_current_status IN ('ENTREGADO', 'FALLIDA') THEN
        RAISE EXCEPTION 'El pedido ya ha sido finalizado con estado %', v_current_status;
END IF;

    -- Actualizar el estado y la fecha si corresponde
    IF p_new_status = 'ENTREGADO' THEN
UPDATE orders
SET status = p_new_status,
    delivery_date = COALESCE(p_delivery_date, NOW())
WHERE id = p_order_id;
ELSE
UPDATE orders
SET status = p_new_status
WHERE id = p_order_id;
END IF;
END;
$$;

alter procedure change_order_status(integer, varchar, timestamp) owner to postgres;

