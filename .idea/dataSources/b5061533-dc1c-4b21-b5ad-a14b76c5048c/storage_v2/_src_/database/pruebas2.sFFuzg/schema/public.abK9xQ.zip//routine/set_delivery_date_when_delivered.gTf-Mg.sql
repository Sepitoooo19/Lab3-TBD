create function set_delivery_date_when_delivered() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.status = 'ENTREGADO' AND NEW.delivery_date IS NULL THEN
        NEW.delivery_date := NOW();
END IF;
RETURN NEW;
END;
$$;

alter function set_delivery_date_when_delivered() owner to postgres;

