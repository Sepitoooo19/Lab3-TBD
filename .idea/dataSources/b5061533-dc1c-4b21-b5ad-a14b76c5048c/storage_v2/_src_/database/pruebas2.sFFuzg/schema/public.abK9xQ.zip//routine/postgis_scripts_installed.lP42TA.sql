create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.5.2'::text || $rev$ 3.5.2 $rev$) AS version $$;

alter function postgis_scripts_installed() owner to postgres;

