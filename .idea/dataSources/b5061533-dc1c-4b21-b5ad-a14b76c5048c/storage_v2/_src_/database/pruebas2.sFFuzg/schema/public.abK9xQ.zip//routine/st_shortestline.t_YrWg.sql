create function st_shortestline(text, text) returns geometry
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_ShortestLine($1::public.geometry, $2::public.geometry);  $$;

alter function st_shortestline(text, text) owner to postgres;

